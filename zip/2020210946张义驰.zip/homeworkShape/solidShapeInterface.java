package homeworkShape;

public interface solidShapeInterface {
    public abstract double calcVolume();
    public abstract double calcSurfaceArea();

    public abstract double getVolume();
    public abstract double getSurfaceArea();
}
